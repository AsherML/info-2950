thriller_movies={"48hrs_dialog.txt":{"title" : "48 Hrs.", "characters":["CATES", "HAMMOND","ELAINE","HADEN","GANZ"], "villain": ["GANZ"], 'year':1982},
"anonymous_dialog.txt":{"title" : "Anonymous", "characters":["YOUNG OXFORD", "YOUNG ELIZABETH","JONSON","SHAKESPEARE","ROBERT CECIL"], "villain": ["ROBERT CECIL"], 'year':2011},
"arcticblue_dialog.txt":{"title" : "Arctic Blue", "characters":["CORBET","ERIC","ANNE MARIE","LEMALLE","MITCHELL"], "villain": ["CORBET"], 'year':1993},
"basicinstinct_dialog.txt":{"title" : "Basic Instinct", "characters":["NICK","CATHERINE","GUS","BETH","LT. WALKER"], "villain": ["CATHERINE"], 'year':1992},
"breakdown_dialog.txt":{"title" : "Breakdown", "characters":["JEFF","RED","AMY","EARL","BILLY"], "villain": ["RED"],'year':1997},
"cellular_dialog.txt":{"title" : "Cellular", "characters":["JESSICA","RYAN","MARILYN","CHLOE","CRAIG"], "villain": ["ETHAN"], 'year':2004},
"entrapment_dialog.txt":{"title" : "Entrapment", "characters":["MAC","GIN","CRUZ","CARLSBY","OKATI"], "villain": ["MAC"], 'year':1999},
"kalifornia_dialog.txt":{"title" : "Kalifornia", "characters":["EARLY","BRIAN","CARRIE","ADELE","CAROL"], "villain": ["EARLY"], 'year' :1993}
}