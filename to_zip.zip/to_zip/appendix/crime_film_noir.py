crime_movies = {"15minutes_dialog.txt" : {'title': "Fifteen Minutes",'characters': ["EDDIE", "JORDY", "ROBERT HAWKINS", "LEON", "NICOLETTE"],"villain": ["EMIL", "OLEG"], "year": 2001}, "aliennation_dialog.txt" :
{'title':'Alien Nation', "characters": ["SYKES", "JETSON", "HARCOURT", "KIPLING", "CASSANDRA"],
"villain": ["HARCOURT"], "year":1988}, "badlieutenant_dialog.txt": {"title": "Bad Lieutenant", "characters": ["LT", "BET COP"
, "JERSEY GIRL", "GIRL", "JC"], "villain": ["JULIO","PAOLO"], "year":1992}, "basicinstinct_dialog.txt":
{'title': "Basic Instinct","characters": ["NICK", "CATHERINE", "GUS", "BETH", "LT. WALKER"], "villain": ["CATHERINE"],
"year":1992}, "blackdahliathe_dialog.txt": {"title": "The Black Dahlia", "characters": ["BUCKY", "KAY", "LEE", "MADELEINE",
"ELIZABETH SHORT"], "villain": ["RAMONA", "MADELEINE"], "year":2006}, "bluevelvet_dialog.txt" : {"title": "Blue Velvet",
"characters": ["DOROTHY", "JEFFREY", "FRANK", "SANDY", "MRS. WILLIAMS"],
"villain": ["FRANK","YELLOW MAN"], "year":1986}, "boondockssaints2allsaintsday_dialog.txt": { "title":"Boondocks Saints 2: All Saints Day",
"characters": ["CONNOR", "MURPHY", "ROMEO", "NOAH", "SIBEAL"], "villain": ["LOUIE"],
"year":2009}, "changeling_dialog.txt" : {"title": "Changeling", "characters": ["CHRISTINE","REV. BRIEGLEB",
"JONES","YBARRA","DAVIS"], "villain": ["GORDON"], "year":2008}, "chaos_dialog.txt" : {"title":"Chaos", "characters": ["CONNERS", "DEKKER", "YORK", "LORENZ", "JENKINS"],
"villain": ["CONNERS","YORK"],"year":2005}, "chinatown_dialog.txt" : {"title": "Chinatown", "characters":["GITTES","MRS. MULWRAY","CROSS","ESCOBAR","YELBURTON"],
"villain": ["CROSS"], "year":1974}, "copycat_dialog.txt" : {"title": "Copycat", "characters":["HELEN","M.J.","RUBEN","DARYLL LEE","PETER"],"villain":["DARYLL LEE","PETER"],"year":1995},
"crank_dialog.txt": {"title": "Crank", "characters":["CHELIOS","EVE","VERONA","CARLITO","DOC MILES"],"villain":["VERONA"],"year":2006},"darkman_dialog.txt" : {"title": "Darkman", "characters": ["PEYTON","DARKMAN","JULIE","STRACK","DURANT"],
"villain": ["STRACK"],"year":1990}, "devilinabluedress_dialog.txt" : {"title": "Devil In A Blue Dress", "characters":["EASY","ALBRIGHT","DAPHNE","MOURSE","TERAN"],"villain":["ALBRIGHT"],"year":1995},
"fracture_dialog.txt": {"title": "Fracture", "characters":["CRAWFORD","WILLY","LOBRUTO","GARDNER","CRAWFORD"],"villain":["CRAWFORD"],"year":2007},
"frenchconnectionthe_dialog.txt" : {"title": "The French Connection", "characters":["DOYLE","CHARNIER","RUSSO","BOCA","NICOLI"],"villain":["CHARNIER"],"year":1971}, "getcarter_dialog.txt" : {"title":"Get Carter","characters":["JACK","ERIC","KINNEAR","ANNA","BRUMBY"],
"villain":["ERIC"],"year":1971}, "girlwiththedragontattoo_dialog.txt" : {"title": "Girl With The Dragon Tattoo","characters":["BLOMKVIST","SALANDER","VANGER","MARTIN","FRODE"],"villain":["MARTIN"],"year":2011}}
